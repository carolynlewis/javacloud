public class Surprise {
    public static void main(String[] args) {
        String s1 = "Hi, Mom!";
        String s2 = "Hi, " + "Mom!";
        if (s1 == s2) {  // true!
            System.out.println("s1 and s2 are the same");
        }
    }
}

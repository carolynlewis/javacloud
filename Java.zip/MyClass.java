class MyClass {
	public static void main(String[ ] args) {
		// in-line comment
		/*
			multi-line comment
		*/
		/** comment
		*/
		System.out.println("Hello World . . . again");
	}
}
public class Chap2 {
	public static void main(String[] args) {
		
		System.out.println("Chapter 2\n----------");
		
			String message; 		// declare the variable message as a string
			int x; 					// declare the variable x as an int
			
			String firstName = "Carolyn";
			String lastName = "Lewis";
			int hour = 11;			// assign the value of 11 to hour
			int minute = 59;		// assign the value of minute to 59
			
			message = "Hello!";		// assign the value of message to "Hello!"
			
		System.out.println("My name is "+firstName+" "+lastName);
		System.out.println("It is "+hour+":"+minute+" and I say "+message);
		System.out.println(message+" "+message);
		System.out.println("I don't know why you say goodbye, I say "+message);
		
			hour-=9;				// change hour to 2
			minute-=41;				// change minute to 18

		System.out.println("Actually it is "+hour+":"+minute+" pm");

			int a = 5;
			int b = a;				// a and b are now equal
			a = 3; 					// a and b are no longer equal
		
		System.out.println("a = "+a+" and b = "+b);
		
			String firstLine = "Hello again!";
		
		System.out.println(firstLine);
		System.out.print("The value of firstLine is ");
		System.out.println(firstLine);
		
			hour+=19;				// change hour to 21
			minute+=8;				// change minute to 26
		
		System.out.println("Now the time is "+hour+":"+minute);
		System.out.print("Number of minutes since midnight: ");
		System.out.println(hour * 60 + minute);
		System.out.println(hour+":"+minute);
		System.out.print("Percent of the hour that has passed: ");
		System.out.println(minute * 100 /60);
		
			double pi = 3.14159;
		
		System.out.println("Pi is equal to: "+pi);
		
			double minuted = 26;
			
		System.out.print("Fracation of the hour that has passed: ");
		System.out.println(minuted / 60.0);
		
			double y = 10.0 / 100.0;
			
		System.out.println(y);
		
									// rounding errors below
		
		System.out.println(0.11 + 0.11 + 0.11 + 0.11 + 0.11 + 0.11 + 0.11 + 0.11 + 0.11 + 0.11);
		System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
		System.out.println(0.1 *10.0);
		
			int money = 12345;		// total number of cents for exactness
			
		System.out.println("Total cents in the bank: "+money);
		
									// concatenation and order of operations
		
		System.out.println(1+2+"Hello");	// adds 1 + 2 before "Hello"
		System.out.println("Hello"+1+2);	// places a 1 and a 2 after Hello
		
									// order of operations
		
			x = (10 + 2) * (8 - 5) / 9;
			
		System.out.println(x);
			
	}
}
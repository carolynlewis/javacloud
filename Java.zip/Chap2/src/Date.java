
public class Date {
	public static void main(String[] args) {
		
		System.out.println("Exercise 2.2");
		System.out.println("----------");
		
			String day = "Sunday";
			int date = 16;
			String month = "August";
			int year = 2020;
			
		System.out.println(day);
		System.out.println(date);
		System.out.println(month);
		System.out.println(year);
		
		System.out.println("----------");
		
		System.out.println(day+", "+month+" "+date+", "+year);
		
		System.out.println("----------");
		
		System.out.println("American format: "+day+", "+month+" "+date+", "+year);
		System.out.println("European format: "+day+" "+date+" "+month+" "+year);
		
	}
}


